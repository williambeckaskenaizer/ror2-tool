import React from 'react';
import './App.css';
import SearchAppBar from './TopMenuBar';
import TableMenu from './TableDrawer'

function App() {
  return (
    <div className="App">
      <SearchAppBar />
      <TableMenu />
    </div>
  );
}

export default App;
