import React from 'react';

export default function charTest(){
   return( <div>
        <h1>chawactews uwu</h1>
    </div>
   );
}